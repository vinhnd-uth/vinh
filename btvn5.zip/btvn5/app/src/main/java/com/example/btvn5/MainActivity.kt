package com.example.btvn5

import android.os.Bundle; import android.widget.Toast
import androidx.activity.ComponentActivity; import androidx.activity.compose.setContent; import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.*; import androidx.compose.foundation.layout.*; import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons; import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.filled.*; import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*; import androidx.compose.runtime.*; import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier; import androidx.compose.ui.draw.clip; import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext; import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.*; import androidx.compose.ui.unit.*
import com.google.firebase.auth.FirebaseAuth

data class Task(val id: Int, val title: String, val category: String, val time: String, val isDone: Boolean)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); enableEdgeToEdge(); setContent { MaterialTheme { MainApp() } } }
}

@Composable
fun MainApp() {
    val ctx = LocalContext.current; var isLogged by remember { mutableStateOf(false) }; var tab by remember { mutableStateOf("HOME") }
    var user by remember { mutableStateOf("Minh Anh") }; var showAdd by remember { mutableStateOf(false) }; var newTitle by remember { mutableStateOf("") }
    val tasks = remember { mutableStateListOf(
        Task(1, "Tập thể dục 30 phút", "Cuộc sống", "06:30", true), Task(2, "Nộp bài tập Lập trình di động", "Học tập", "09:00", true),
        Task(3, "Ôn chương 3 – Cấu trúc dữ liệu", "Học tập", "14:00", false), Task(4, "Đi chợ mua đồ cho tuần", "Cuộc sống", "17:30", false)
    )}

    fun login(u: String) { runCatching { FirebaseAuth.getInstance().signInAnonymously() }; user = u; isLogged = true; tab = "HOME"; Toast.makeText(ctx, "Đăng nhập thành công!", Toast.LENGTH_SHORT).show() }
    fun toggle(t: Task) { val i = tasks.indexOfFirst { it.id == t.id }; if (i != -1) tasks[i] = t.copy(isDone = !t.isDone) }

    if (showAdd) {
        AlertDialog(onDismissRequest = { showAdd = false }, title = { Text("Thêm công việc mới", fontWeight = FontWeight.Bold) },
            text = { OutlinedTextField(value = newTitle, onValueChange = { newTitle = it }, label = { Text("Tên công việc") }, modifier = Modifier.fillMaxWidth()) },
            confirmButton = { Button(onClick = { if (newTitle.isNotBlank()) { tasks.add(Task(tasks.size + 1, newTitle, "Học tập", "18:00", false)); newTitle = ""; Toast.makeText(ctx, "Đã thêm công việc!", Toast.LENGTH_SHORT).show() }; showAdd = false }) { Text("Thêm") } },
            dismissButton = { TextButton(onClick = { showAdd = false }) { Text("Hủy") } }
        )
    }

    if (!isLogged) LoginScreen(onLogin = { login(it) }) else Scaffold(containerColor = Color(0xFFF8FAFC), bottomBar = {
        NavigationBar(containerColor = Color.White) {
            NavigationBarItem(tab == "HOME", { tab = "HOME" }, { Icon(Icons.Default.Home, null) }, label = { Text("Trang chủ", fontSize = 11.sp) })
            NavigationBarItem(tab == "LIST", { tab = "LIST" }, { Icon(Icons.AutoMirrored.Filled.List, null) }, label = { Text("Danh sách", fontSize = 11.sp) })
            Box(Modifier.size(46.dp).clip(CircleShape).background(Color(0xFF2563EB)).clickable { showAdd = true }, Alignment.Center) { Icon(Icons.Default.Add, null, tint = Color.White) }
            NavigationBarItem(tab == "NOTIF", { tab = "NOTIF" }, { Icon(Icons.Outlined.Notifications, null) }, label = { Text("Thông báo", fontSize = 11.sp) })
            NavigationBarItem(tab == "PROFILE", { tab = "PROFILE" }, { Icon(Icons.Default.Settings, null) }, label = { Text("Cài đặt", fontSize = 11.sp) })
        }
    }) { p -> Box(Modifier.padding(p)) {
        when (tab) {
            "HOME" -> HomeScreen(user, tasks, onToggle = { toggle(it) }, onProfile = { tab = "PROFILE" }, onSeeAll = { tab = "LIST" })
            "LIST" -> TaskListScreen(tasks, onToggle = { toggle(it) }, onAdd = { showAdd = true })
            "NOTIF" -> NotificationScreen()
            "PROFILE" -> ProfileScreen(user, tasks, onBack = { tab = "HOME" }, onLogout = { runCatching { FirebaseAuth.getInstance().signOut() }; isLogged = false; Toast.makeText(ctx, "Đã đăng xuất!", Toast.LENGTH_SHORT).show() })
        }
    }}
}

@Composable
fun LoginScreen(onLogin: (String) -> Unit) {
    Scaffold(containerColor = Color(0xFFF8FAFC)) { p ->
        Column(Modifier.fillMaxSize().padding(p).verticalScroll(rememberScrollState()).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Box(Modifier.size(72.dp).clip(RoundedCornerShape(20.dp)).background(Color(0xFF2563EB)), Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) { Box(Modifier.width(28.dp).height(5.dp).clip(CircleShape).background(Color.White)); Spacer(Modifier.height(5.dp)); Box(Modifier.width(20.dp).height(5.dp).clip(CircleShape).background(Color.White)) }
            }
            Spacer(Modifier.height(20.dp)); Text("Chào mừng đến với\nUTH Todo", fontWeight = FontWeight.Bold, fontSize = 24.sp, textAlign = TextAlign.Center, color = Color(0xFF0F172A))
            Text("Đăng nhập để lưu công việc và đồng bộ\ntrên mọi thiết bị của bạn.", fontSize = 13.sp, textAlign = TextAlign.Center, color = Color(0xFF64748B), modifier = Modifier.padding(top = 8.dp, bottom = 36.dp))
            OutlinedButton(onClick = { onLogin("Minh Anh") }, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth().height(52.dp)) { Text("G", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Color(0xFF4285F4)); Spacer(Modifier.width(10.dp)); Text("Tiếp tục với Google", fontSize = 15.sp, color = Color(0xFF1E293B)) }
            Row(Modifier.fillMaxWidth().padding(vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) { HorizontalDivider(Modifier.weight(1f)); Text("hoặc", modifier = Modifier.padding(horizontal = 8.dp), color = Color(0xFF94A3B8), fontSize = 13.sp); HorizontalDivider(Modifier.weight(1f)) }
            OutlinedButton(onClick = { onLogin("Khách UTH") }, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth().height(52.dp)) { Text("Dùng thử không cần tài khoản", fontSize = 14.sp, color = Color(0xFF475569)) }
            Spacer(Modifier.height(40.dp)); Text("Khi tiếp tục, bạn đồng ý với Điều khoản sử dụng và Chính sách quyền riêng tư của UTH Todo.", fontSize = 11.sp, textAlign = TextAlign.Center, color = Color(0xFF94A3B8))
        }
    }
}

@Composable
fun HomeScreen(user: String, tasks: List<Task>, onToggle: (Task) -> Unit, onProfile: () -> Unit, onSeeAll: () -> Unit) {
    val done = tasks.count { it.isDone }; val pct = if (tasks.isNotEmpty()) (done * 100) / tasks.size else 0
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
            Row(Modifier.clickable { onProfile() }, verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(42.dp).clip(CircleShape).background(Color(0xFF1E3A8A)), Alignment.Center) { Text("MA", color = Color.White, fontWeight = FontWeight.Bold) }
                Spacer(Modifier.width(10.dp)); Column { Text("Thứ Ba, 20 tháng 10", fontSize = 11.sp, color = Color(0xFF64748B)); Text("Chào $user!", fontSize = 17.sp, fontWeight = FontWeight.Bold) }
            }
            IconButton(onClick = {}, Modifier.clip(CircleShape).background(Color.White)) { Icon(Icons.Outlined.Notifications, null, tint = Color(0xFF64748B)) }
        }
        Card(Modifier.fillMaxWidth().padding(vertical = 16.dp), RoundedCornerShape(20.dp), CardDefaults.cardColors(containerColor = Color(0xFF2563EB))) {
            Row(Modifier.padding(20.dp), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                Column { Text("Tiến độ hôm nay", color = Color.White.copy(0.8f), fontSize = 13.sp); Text("$done/${tasks.size} việc", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold); Text("Đã hơn nửa chặng, cố lên!", color = Color.White.copy(0.9f), fontSize = 12.sp) }
                Box(Modifier.size(60.dp), Alignment.Center) { CircularProgressIndicator(progress = { pct / 100f }, modifier = Modifier.fillMaxSize(), color = Color.White, trackColor = Color.White.copy(0.3f), strokeWidth = 6.dp); Text("$pct%", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
            }
        }
        Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(12.dp)) {
            Card(Modifier.weight(1f), RoundedCornerShape(16.dp), CardDefaults.cardColors(containerColor = Color.White)) { Column(Modifier.padding(14.dp)) { Box(Modifier.size(36.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xFFEFF6FF)), Alignment.Center) { Icon(Icons.Default.School, null, tint = Color(0xFF2563EB)) }; Text("Học tập", fontWeight = FontWeight.Bold, fontSize = 15.sp); Text("${tasks.count { it.category == "Học tập" && !it.isDone }} việc còn lại", fontSize = 12.sp, color = Color(0xFF64748B)) } }
            Card(Modifier.weight(1f), RoundedCornerShape(16.dp), CardDefaults.cardColors(containerColor = Color.White)) { Column(Modifier.padding(14.dp)) { Box(Modifier.size(36.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xFFFFF7ED)), Alignment.Center) { Icon(Icons.Default.Home, null, tint = Color(0xFFEA580C)) }; Text("Cuộc sống", fontWeight = FontWeight.Bold, fontSize = 15.sp); Text("${tasks.count { it.category == "Cuộc sống" && !it.isDone }} việc còn lại", fontSize = 12.sp, color = Color(0xFF64748B)) } }
        }
        Row(Modifier.fillMaxWidth().padding(top = 16.dp, bottom = 8.dp), Arrangement.SpaceBetween, Alignment.CenterVertically) { Text("Việc hôm nay", fontWeight = FontWeight.Bold, fontSize = 16.sp); Text("Xem tất cả", color = Color(0xFF2563EB), fontSize = 13.sp, modifier = Modifier.clickable { onSeeAll() }) }
        tasks.forEach { t ->
            Card(Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable { onToggle(t) }, RoundedCornerShape(14.dp), CardDefaults.cardColors(containerColor = Color.White)) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(if (t.isDone) Icons.Default.CheckCircle else Icons.Outlined.Circle, null, tint = if (t.isDone) Color(0xFF2563EB) else Color(0xFFCBD5E1), modifier = Modifier.size(22.dp))
                    Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                        Text(t.title, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = if (t.isDone) Color(0xFF94A3B8) else Color(0xFF1E293B), textDecoration = if (t.isDone) TextDecoration.LineThrough else TextDecoration.None)
                        Text("${t.category}  ${t.time}", fontSize = 11.sp, color = Color(0xFF94A3B8))
                    }
                    Icon(Icons.Default.ChevronRight, null, tint = Color(0xFFCBD5E1), modifier = Modifier.size(18.dp))
                }
            }
        }
    }
}

@Composable
fun TaskListScreen(tasks: List<Task>, onToggle: (Task) -> Unit, onAdd: () -> Unit) {
    var cat by remember { mutableStateOf("Tất cả") }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) { Text("Danh sách công việc", fontWeight = FontWeight.Bold, fontSize = 20.sp); Button(onClick = onAdd, shape = RoundedCornerShape(10.dp)) { Text("+ Thêm") } }
        Row(Modifier.padding(vertical = 12.dp), Arrangement.spacedBy(8.dp)) { listOf("Tất cả", "Học tập", "Cuộc sống").forEach { c -> FilterChip(selected = cat == c, onClick = { cat = c }, label = { Text(c) }) } }
        Column(Modifier.verticalScroll(rememberScrollState())) {
            tasks.filter { cat == "Tất cả" || it.category == cat }.forEach { t ->
                Card(Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable { onToggle(t) }, RoundedCornerShape(12.dp), CardDefaults.cardColors(containerColor = Color.White)) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(if (t.isDone) Icons.Default.CheckCircle else Icons.Outlined.Circle, null, tint = if (t.isDone) Color(0xFF2563EB) else Color(0xFFCBD5E1), modifier = Modifier.size(22.dp))
                        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) { Text(t.title, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = if (t.isDone) Color(0xFF94A3B8) else Color(0xFF1E293B), textDecoration = if (t.isDone) TextDecoration.LineThrough else TextDecoration.None); Text("${t.category} • ${t.time}", fontSize = 12.sp, color = Color(0xFF64748B)) }
                    }
                }
            }
        }
    }
}

@Composable
fun NotificationScreen() {
    val items = listOf("Nhắc nhở: Ôn chương 3 – Cấu trúc dữ liệu lúc 14:00" to "Hôm nay", "Đã hoàn thành: Tập thể dục 30 phút" to "Hôm nay", "Chào mừng bạn đến với UTH Todo!" to "Hôm qua")
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Thông báo", fontWeight = FontWeight.Bold, fontSize = 20.sp); Spacer(Modifier.height(12.dp))
        Column(Modifier.verticalScroll(rememberScrollState())) { items.forEach { (txt, time) ->
            Card(Modifier.fillMaxWidth().padding(vertical = 4.dp), RoundedCornerShape(12.dp), CardDefaults.cardColors(containerColor = Color.White)) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(36.dp).clip(CircleShape).background(Color(0xFFEFF6FF)), Alignment.Center) { Icon(Icons.Outlined.Notifications, null, tint = Color(0xFF2563EB)) }; Spacer(Modifier.width(12.dp)); Column { Text(txt, fontSize = 13.sp, fontWeight = FontWeight.Medium); Text(time, fontSize = 11.sp, color = Color(0xFF94A3B8)) } }
            }
        }}
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(user: String, tasks: List<Task>, onBack: () -> Unit, onLogout: () -> Unit) {
    val done = tasks.count { it.isDone }; val pending = tasks.size - done; val pct = if (tasks.isNotEmpty()) (done * 100) / tasks.size else 0
    Scaffold(topBar = { TopAppBar(title = { Box(Modifier.fillMaxWidth(), Alignment.Center) { Text("Hồ sơ", fontWeight = FontWeight.Bold, fontSize = 17.sp) } }, navigationIcon = { Row(Modifier.clickable { onBack() }.padding(8.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = Color(0xFF2563EB), modifier = Modifier.size(18.dp)); Text("Cài đặt", color = Color(0xFF2563EB), fontSize = 14.sp) } }, actions = { Spacer(Modifier.width(70.dp)) }, colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFFF8FAFC))) }, containerColor = Color(0xFFF8FAFC)) { p ->
        Column(Modifier.fillMaxSize().padding(p).verticalScroll(rememberScrollState()).padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(86.dp).clip(CircleShape).background(Color(0xFF1E3A8A)), Alignment.Center) { Text("MA", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 30.sp) }
            Text(user, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp)); Text("minhanh@example.com", fontSize = 13.sp, color = Color(0xFF64748B))
            Surface(Modifier.padding(top = 10.dp), RoundedCornerShape(20.dp), Color(0xFFDCFCE7)) { Row(Modifier.padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Check, null, tint = Color(0xFF166534), modifier = Modifier.size(14.dp)); Text("✓ Đã liên kết tài khoản Google", fontSize = 12.sp, color = Color(0xFF166534), modifier = Modifier.padding(start = 4.dp)) } }
            Row(Modifier.fillMaxWidth().padding(vertical = 20.dp), Arrangement.spacedBy(10.dp)) {
                listOf("$done" to "Việc đã xong", "$pending" to "Đang chờ", "$pct%" to "Hoàn thành").forEach { (v, l) ->
                    Card(Modifier.weight(1f), RoundedCornerShape(14.dp), CardDefaults.cardColors(containerColor = Color.White)) { Column(Modifier.fillMaxWidth().padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) { Text(v, fontWeight = FontWeight.Bold, fontSize = 18.sp); Text(l, fontSize = 11.sp, color = Color(0xFF64748B)) } }
                }
            }
            Card(Modifier.fillMaxWidth(), RoundedCornerShape(16.dp), CardDefaults.cardColors(containerColor = Color.White)) {
                Column(Modifier.padding(16.dp)) {
                    Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) { Text("Tuần này", fontWeight = FontWeight.Bold, fontSize = 14.sp); Text("Việc xong mỗi ngày", fontSize = 12.sp, color = Color(0xFF64748B)) }
                    Row(Modifier.fillMaxWidth().height(90.dp).padding(top = 16.dp), Arrangement.SpaceBetween, Alignment.Bottom) {
                        listOf("T2" to 3, "T3" to 4, "T4" to 1, "T5" to 2, "T6" to 1, "T7" to 0, "CN" to 1).forEach { (d, c) ->
                            val high = d in listOf("T2", "T3")
                            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom) {
                                Box(Modifier.width(14.dp).height(if (c > 0) (c * 16).dp else 8.dp).clip(RoundedCornerShape(4.dp)).background(if (high) Color(0xFF2563EB) else Color(0xFFE2E8F0)))
                                Text(d, fontSize = 11.sp, fontWeight = if (high) FontWeight.Bold else FontWeight.Normal, modifier = Modifier.padding(top = 4.dp))
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(30.dp))
            OutlinedButton(onClick = onLogout, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth(0.6f).height(46.dp).border(1.dp, Color(0xFFFCA5A5), RoundedCornerShape(14.dp))) {
                Icon(Icons.AutoMirrored.Filled.Logout, null, tint = Color(0xFFEF4444), modifier = Modifier.size(16.dp)); Text("Đăng xuất", color = Color(0xFFEF4444), fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.padding(start = 6.dp))
            }
        }
    }
}
