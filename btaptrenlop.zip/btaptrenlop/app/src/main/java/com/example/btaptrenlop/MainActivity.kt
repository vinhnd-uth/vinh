package com.example.btaptrenlop

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.*

// ==========================================
// MÀU SẮC DÙNG CHUNG TRONG ỨNG DỤNG
// ==========================================
val UthBlue = Color(0xFF3B62FF) // Mã màu xanh lam UTH
val UthRed = Color(0xFFC02B21)  // Mã màu đỏ UTH
val UthGreen = Color(0xFF00685D) // Mã màu xanh lá UTH
val SmartBlue = Color(0xFF4A90E2) // Mã màu xanh da trời SmartTasks

// ==========================================
// BÀI TẬP 1 & BÀI TẬP 2: MÔ HÌNH DỮ LIỆU & OOP
// ==========================================

// BT1: Data class lưu dữ liệu tiêu đề và nội dung cho từng trang Onboarding
data class OnboardingPage(val title: String, val desc: String, val btnText: String) // Lưu tiêu đề, mô tả và chữ trên nút bấm

// Danh sách chứa nội dung của 3 trang Onboarding
val onboardingPages = listOf(
    OnboardingPage("Mọi việc, gọn trong một chỗ", "Ghi lại bài tập, việc nhà, lịch hẹn. Không còn quên việc nào.", "Tiếp tục"), // Trang 1
    OnboardingPage("Chia theo Học tập và Cuộc sống", "Mỗi việc có nhóm riêng, nhìn là biết hôm nay cần lo gì.", "Tiếp tục"), // Trang 2
    OnboardingPage("Nhắc đúng lúc", "Bật thông báo để UTH Todo nhắc bạn trước hạn chót.", "Bắt đầu ngay") // Trang 3
)

// BT2: Áp dụng đủ 4 đặc trưng của Lập trình Hướng đối tượng (OOP):
abstract class Person { // 1. Tính Trừu tượng (Abstraction): Lớp trừu tượng Person
    private var _name: String = "" // 2. Tính Đóng gói (Encapsulation): Thuộc tính private _name
    var name: String
        get() = _name // Getter lấy giá trị tên
        set(value) { _name = value } // Setter gán giá trị tên mới

    abstract fun getRole(): String // Phương thức thuần ảo lấy vai trò
}

class Student(name: String) : Person() { // 3. Tính Kế thừa (Inheritance): Lớp Student kế thừa từ Person
    init { this.name = name } // Khởi tạo tên sinh viên khi tạo đối tượng
    
    val dsSachMuon = mutableStateListOf<Book>() // Danh sách chứa các cuốn sách sinh viên này đã mượn
    
    override fun getRole() = "Sinh viên" // 4. Tính Đa hình (Polymorphism): Ghi đè phương thức getRole() từ Lớp cha
}

interface Borrowable { fun borrow(sv: Student) } // Interface định nghĩa hành vi mượn sách

class Book(val title: String) : Borrowable { // Lớp Book hiện thực hóa interface Borrowable
    var isAvailable by mutableStateOf(true) // Biến lưu trạng thái sách còn sẵn trong thư viện hay không

    override fun borrow(sv: Student) { // Hàm xử lý khi mượn sách: Đổi trạng thái khả dụng và thêm vào danh sách của SV
        if (isAvailable) { isAvailable = false; sv.dsSachMuon.add(this) }
    }

    fun returnBook(sv: Student) { // Hàm xử lý khi trả sách: Trả lại trạng thái khả dụng và xoá khỏi danh sách của SV
        if (sv.dsSachMuon.contains(this)) { isAvailable = true; sv.dsSachMuon.remove(this) }
    }
}

// ==========================================
// MAIN ACTIVITY & ĐIỀU HƯỚNG (NAVIGATION)
// ==========================================
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme { AppNavigation() } // Gọi giao diện chính kèm bộ điều hướng
        }
    }
}

@Composable
fun AppNavigation() {
    val navController = rememberNavController() // Khởi tạo Controller quản lý việc chuyển màn hình

    NavHost(navController = navController, startDestination = "menu") { // Thiết lập luồng xuất phát từ màn menu
        composable("menu") { MenuScreen(navController) } // Màn hình Menu chính chọn bài tập

        // --- LUỒNG BÀI TẬP 1 ---
        composable("start") { StartScreen(navController) } // Màn hình xanh khởi động BT1
        composable("onboarding/{page}") { backStack -> // Màn hình Onboarding nhận chỉ số trang qua URL
            val page = backStack.arguments?.getString("page")?.toIntOrNull() ?: 0 // Đọc tham số chỉ số trang
            OnboardingScreen(navController, page) // Hiển thị giao diện Onboarding tương ứng
        }

        // --- LUỒNG BÀI TẬP 2 ---
        composable("thuvien") { ThuVienScreen(navController) } // Màn hình Quản lý thư viện OOP

        // --- LUỒNG BÀI TẬP 3 (Truyền dữ liệu tiến) ---
        composable("forgot") { ForgotPasswordScreen(navController) } // Màn 1: Quên mật khẩu
        composable("verify/{email}") { backStack -> // Màn 2: Nhập OTP (nhận email từ Màn 1)
            VerifyCodeScreen(navController, backStack.arguments?.getString("email") ?: "")
        }
        composable("create/{email}/{otp}") { backStack -> // Màn 3: Tạo Pass mới (nhận email + otp từ Màn 2)
            CreatePasswordScreen(
                navController,
                backStack.arguments?.getString("email") ?: "",
                backStack.arguments?.getString("otp") ?: ""
            )
        }
        composable("confirm/{email}/{otp}/{pass}") { backStack -> // Màn 4: Xác nhận (nhận email + otp + pass từ Màn 3)
            ConfirmScreen(
                navController,
                backStack.arguments?.getString("email") ?: "",
                backStack.arguments?.getString("otp") ?: "",
                backStack.arguments?.getString("pass") ?: ""
            )
        }
    }
}
@Composable
fun MenuScreen(navController: NavController) {
    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp), // Phủ kín màn hình và cách lề 24dp
        horizontalAlignment = Alignment.CenterHorizontally, // Căn giữa theo chiều ngang
        verticalArrangement = Arrangement.Center // Căn giữa theo chiều dọc
    ) {
        Text("BÀI TẬP VỀ NHÀ", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = UthRed) // Tiêu đề đỏ
        Spacer(modifier = Modifier.height(32.dp)) // Tạo khoảng trống 32dp
        MenuButton("BT1: UTH Todo") { navController.navigate("start") } // Nút mở BT1
        MenuButton("BT2: Quản lý Thư viện", Color(0xFF2E7D32)) { navController.navigate("thuvien") } // Nút mở BT2
        MenuButton("BT3: SmartTasks", Color(0xFFF57C00)) { navController.navigate("forgot") } // Nút mở BT3
    }
}

@Composable
fun MenuButton(text: String, color: Color = UthBlue, onClick: () -> Unit) {
    Button(
        onClick = onClick, // Gắn sự kiện khi bấm nút
        modifier = Modifier.fillMaxWidth().height(50.dp).padding(vertical = 4.dp), // Nút rộng full màn hình, cao 50dp
        colors = ButtonDefaults.buttonColors(containerColor = color) // Đặt màu nền cho nút
    ) { Text(text, fontSize = 16.sp) } // Chữ trên nút
}
// BÀI TẬP 1: GIAO DIỆN ONBOARDING (UTH TODO V2)
@Composable
fun UthLogoIcon() {
    Box(modifier = Modifier.size(90.dp).background(Color.White, RoundedCornerShape(24.dp)), contentAlignment = Alignment.Center) { // Thẻ vuông trắng bo góc chứa Logo
        Column(verticalArrangement = Arrangement.spacedBy(6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            repeat(3) { index -> // Vẽ 3 dòng gạch đại diện cho todo list
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (index == 0) { // Dòng 1 có ô tích xanh
                        Box(modifier = Modifier.size(16.dp).background(UthBlue, CircleShape), contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.Check, null, tint = Color.White, modifier = Modifier.size(10.dp))
                        }
                    } else { // Dòng 2 và 3 là ô tròn rỗng
                        Box(modifier = Modifier.size(16.dp).drawBehind { drawCircle(color = UthBlue, style = Stroke(width = 2.dp.toPx())) })
                    }
                    Box(modifier = Modifier.size(28.dp, 4.dp).background(UthBlue, CircleShape)) // Thanh gạch ngang
                }
            }
        }
    }
}

@Composable
fun StartScreen(navController: NavController) {
    Column(
        modifier = Modifier.fillMaxSize().background(UthBlue).clickable { navController.navigate("onboarding/0") }.padding(24.dp), // Bấm vào toàn màn hình để bắt đầu
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.weight(1f)) // Đẩy logo ra giữa
        UthLogoIcon() // Vẽ Logo UTH Todo
        Spacer(modifier = Modifier.height(24.dp))
        Text("UTH Todo", color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Bold) // Tiêu đề ứng dụng
        Spacer(modifier = Modifier.height(8.dp))
        Text("Việc học, việc nhà – gọn gàng mỗi ngày", color = Color.White.copy(alpha = 0.9f), fontSize = 14.sp) // Câu slogan
        Spacer(modifier = Modifier.weight(1f)) // Đẩy thông tin phiên bản xuống đáy
        Box(modifier = Modifier.size(30.dp, 3.dp).background(Color.White.copy(alpha = 0.6f), CircleShape)) // Thanh chỉ báo dưới
        Spacer(modifier = Modifier.height(8.dp))
        Text("Phiên bản 2.1.0", color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp) // Thông tin phiên bản
    }
}

@Composable
fun OnboardingScreen(navController: NavController, page: Int) {
    val data = onboardingPages[page] // Lấy dữ liệu trang Onboarding tương ứng với trang hiện tại
    Column(modifier = Modifier.fillMaxSize().background(Color.White).padding(24.dp)) {
        // Thanh Header chứa Logo nhỏ và Nút Bỏ qua
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(modifier = Modifier.size(28.dp).background(UthBlue, RoundedCornerShape(8.dp)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Check, null, tint = Color.White, modifier = Modifier.size(16.dp))
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text("UTH Todo", color = UthBlue, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
            TextButton(onClick = { navController.navigate("menu") { popUpTo(0) } }) { // Bấm nút Bỏ qua để về Menu
                Text("Bỏ qua", color = Color.Gray, fontSize = 14.sp)
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Khung xám chứa Đồ họa minh họa vẽ bằng Compose
        Box(
            modifier = Modifier.fillMaxWidth().weight(1f).background(Color(0xFFF3F5F9), RoundedCornerShape(24.dp)),
            contentAlignment = Alignment.Center
        ) {
            when (page) {
                0 -> OnboardGraphic1() // Đồ họa minh họa trang 1
                1 -> OnboardGraphic2() // Đồ họa minh họa trang 2
                2 -> OnboardGraphic3() // Đồ họa minh họa trang 3
            }
        }

        Spacer(modifier = Modifier.height(32.dp))
        Text(data.title, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.Black) // Tiêu đề trang
        Spacer(modifier = Modifier.height(8.dp))
        Text(data.desc, color = Color.Gray, fontSize = 13.sp, lineHeight = 18.sp) // Nội dung mô tả trang

        Spacer(modifier = Modifier.height(32.dp))

        // Thanh dấu chấm chuyển trang và Nút bấm Tiếp tục
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                repeat(3) { i -> // Vẽ 3 dấu chấm chỉ báo vị trí trang
                    Box(modifier = Modifier.size(if (i == page) 24.dp else 8.dp, 8.dp).clip(CircleShape).background(if (i == page) UthBlue else Color(0xFFD1D5DB)))
                }
            }
            Button(
                onClick = { if (page < 2) navController.navigate("onboarding/${page + 1}") else navController.navigate("menu") { popUpTo(0) } }, // Chuyển sang trang tiếp theo
                colors = ButtonDefaults.buttonColors(containerColor = UthBlue),
                modifier = Modifier.height(48.dp).width(140.dp),
                shape = RoundedCornerShape(12.dp)
            ) { Text(data.btnText, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color.White) }
        }
    }
}

// Đồ họa minh họa 1: Danh sách công việc có tích chọn
@Composable
fun OnboardGraphic1() {
    Column(modifier = Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        repeat(3) { i ->
            Row(
                modifier = Modifier.fillMaxWidth().height(48.dp).background(Color.White, RoundedCornerShape(12.dp)).padding(horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (i == 0) {
                    Box(modifier = Modifier.size(22.dp).background(UthBlue, CircleShape), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Check, null, tint = Color.White, modifier = Modifier.size(14.dp))
                    }
                } else {
                    Box(modifier = Modifier.size(22.dp).drawBehind { drawCircle(color = Color.LightGray, style = Stroke(width = 2.dp.toPx())) })
                }
                Spacer(modifier = Modifier.width(12.dp))
                Box(modifier = Modifier.fillMaxWidth(0.8f).height(10.dp).background(Color(0xFFE5E7EB), CircleShape))
            }
        }
    }
}

// Đồ họa minh họa 2: Thẻ phân loại Học tập và Cuộc sống
@Composable
fun OnboardGraphic2() {
    Column(modifier = Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        listOf("Học tập" to Color(0xFFE8F0FE) to UthBlue, "Cuộc sống" to Color(0xFFFFF3E0) to Color(0xFFE65100)).forEach { (data, textColor) ->
            val (label, bgColor) = data
            Box(modifier = Modifier.fillMaxWidth().height(54.dp).background(Color.White, RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                Box(modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp).background(bgColor, RoundedCornerShape(8.dp))) {
                    Text(label, color = textColor, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
            }
        }
    }
}

// Đồ họa minh họa 3: Qủa chuông và Banner thông báo nhắc nhở
@Composable
fun OnboardGraphic3() {
    Column(modifier = Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(modifier = Modifier.size(64.dp).background(Color(0xFFE8F0FE), CircleShape), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.Notifications, null, tint = UthBlue, modifier = Modifier.size(32.dp))
        }
        Box(modifier = Modifier.background(Color.White, RoundedCornerShape(12.dp)).padding(horizontal = 20.dp, vertical = 10.dp)) {
            Text("Ôn bài Toán lúc 13:00", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.Black)
        }
    }
}

// BÀI TẬP 2: QUẢN LÝ THƯ VIỆN (HỆ THỐNG OOP)

@Composable
fun ThuVienScreen(navController: NavController) {
    val context = LocalContext.current // Context ứng dụng phục vụ hiển thị Toast thông báo
    val dsSinhVien = remember { mutableStateListOf(Student("Nguyen Van A")) } // Quản lý danh sách các Sinh viên
    val dsSach = remember { mutableStateListOf(Book("Sách 01"), Book("Sách 02"), Book("Sách 03"), Book("Sách 04"), Book("Sách 05")) } // Quản lý danh sách các cuốn Sách
    var selectedStudent by remember { mutableStateOf(dsSinhVien.first()) } // Sinh viên đang được chọn mượn sách
    var nameInput by remember { mutableStateOf(selectedStudent.name) } // Chuỗi tên gõ trên khung TextField
    var selectedBooks by remember { mutableStateOf(selectedStudent.dsSachMuon.toSet()) } // Tập hợp sách được tích chọn Checkbox
    var currentTab by remember { mutableIntStateOf(0) } // Tab màn hình hiện tại (0: Quản lý, 1: DS Sách, 2: Sinh viên)

    Scaffold(
        bottomBar = {
            // Thanh Bottom Navigation 3 Tab dưới màn hình
            NavigationBar(containerColor = Color.White) {
                listOf("Quản lý" to Icons.Default.Home, "DS Sách" to Icons.Default.List, "Sinh viên" to Icons.Default.Person).forEachIndexed { i, (label, icon) ->
                    NavigationBarItem(
                        icon = { Icon(icon, "") },
                        label = { Text(label) },
                        selected = currentTab == i, // Đánh dấu tab đang chọn
                        onClick = { currentTab = i } // Chuyển Tab khi bấm
                    )
                }
            }
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp).background(Color.White)) {
            // Thanh tiêu đề phía trên có Nút quay lại
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { navController.popBackStack() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "") }
                Text("Hệ thống\nQuản lý Thư viện", fontSize = 20.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, modifier = Modifier.weight(1f))
            }
            Spacer(modifier = Modifier.height(24.dp))

            when (currentTab) {
                // Tab 0: Giao diện mượn / trả sách cho Sinh viên
                0 -> TabQuanLy(dsSinhVien, dsSach, selectedStudent, nameInput, selectedBooks,
                    onNameChange = { nameInput = it },
                    onStudentSwitch = { sv -> selectedStudent = sv; selectedBooks = sv.dsSachMuon.toSet() },
                    onSelectionChange = { selectedBooks = it },
                    onSave = { // Xử lý sự kiện mượn / trả sách khi bấm nút Thêm
                        val toReturn = selectedStudent.dsSachMuon.filter { it !in selectedBooks } // Sách bị bỏ tick -> Trả
                        toReturn.forEach { it.returnBook(selectedStudent) }
                        val toBorrow = selectedBooks.filter { it !in selectedStudent.dsSachMuon } // Sách được tick mới -> Mượn
                        toBorrow.forEach { it.borrow(selectedStudent) }
                        Toast.makeText(context, "Cập nhật mượn sách thành công!", Toast.LENGTH_SHORT).show()
                    }
                )
                // Tab 1: Giao diện Thêm danh sách Sách mới
                1 -> TabThemInput(
                    title = "Tạo danh sách sách",
                    label = "Tên sách mới",
                    btnText = "Tạo",
                    onAdd = { name -> dsSach.add(Book(name)); Toast.makeText(context, "Đã thêm sách mới!", Toast.LENGTH_SHORT).show() }, // Thêm sách vào danh sách
                    listContent = {
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(dsSach) { s -> // Hiển thị danh sách tất cả các cuốn sách
                                Row(modifier = Modifier.fillMaxWidth().background(Color(0xFFF3F4F6), RoundedCornerShape(8.dp)).padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text(s.title, fontWeight = FontWeight.Bold)
                                    Text(if (s.isAvailable) "Có sẵn" else "Đã mượn", color = if (s.isAvailable) Color(0xFF2E7D32) else UthRed, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                )
                // Tab 2: Giao diện Thêm danh sách Sinh viên mới
                2 -> TabThemInput(
                    title = "Tạo danh sách sinh viên",
                    label = "Tên sinh viên mới",
                    btnText = "Tạo",
                    onAdd = { name -> dsSinhVien.add(Student(name)); Toast.makeText(context, "Đã thêm sinh viên!", Toast.LENGTH_SHORT).show() }, // Thêm sinh viên mới
                    listContent = {
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(dsSinhVien) { sv -> // Hiển thị danh sách tất cả các sinh viên
                                Box(modifier = Modifier.fillMaxWidth().background(Color(0xFFF3F4F6), RoundedCornerShape(12.dp)).padding(16.dp)) {
                                    Column {
                                        Text("Họ và tên: ${sv.name}", fontWeight = FontWeight.Bold)
                                        Text("Đang mượn: ${sv.dsSachMuon.size} cuốn sách", color = Color.Gray)
                                    }
                                }
                            }
                        }
                    }
                )
            }
        }
    }
}

// Hàm UI phụ trách Tab Quản lý Mượn Sách
@Composable
fun ColumnScope.TabQuanLy(
    dsSinhVien: List<Student>,
    dsSach: List<Book>,
    selectedStudent: Student,
    nameInput: String,
    selectedBooks: Set<Book>,
    onNameChange: (String) -> Unit,
    onStudentSwitch: (Student) -> Unit,
    onSelectionChange: (Set<Book>) -> Unit,
    onSave: () -> Unit
) {
    Text("Sinh viên", fontWeight = FontWeight.Bold)
    Spacer(modifier = Modifier.height(8.dp))
    Row(verticalAlignment = Alignment.CenterVertically) {
        OutlinedTextField(value = nameInput, onValueChange = onNameChange, modifier = Modifier.weight(1f), singleLine = true, shape = RoundedCornerShape(8.dp)) // Khung nhập tên SV
        Spacer(modifier = Modifier.width(8.dp))
        Button(
            onClick = { // Tìm hoặc tạo Sinh viên theo tên rồi chuyển đổi người thao tác
                val sv = dsSinhVien.find { it.name == nameInput } ?: Student(nameInput).also { (dsSinhVien as MutableList).add(it) }
                onStudentSwitch(sv)
            },
            shape = RoundedCornerShape(8.dp), colors = ButtonDefaults.buttonColors(containerColor = UthBlue), modifier = Modifier.height(56.dp)
        ) { Text("Thay đổi") }
    }

    Spacer(modifier = Modifier.height(24.dp))
    Text("Danh sách sách", fontWeight = FontWeight.Bold)
    Spacer(modifier = Modifier.height(8.dp))

    // Khung màu xám chứa Danh sách sách có Checkbox
    Box(modifier = Modifier.fillMaxWidth().weight(1f).background(Color(0xFFE5E7EB), RoundedCornerShape(12.dp)).padding(12.dp)) {
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(dsSach) { s ->
                val isOtherBorrowed = !s.isAvailable && !selectedStudent.dsSachMuon.contains(s) // Kiểm tra xem sách có bị người khác mượn hay không
                val isChecked = selectedBooks.contains(s) // Kiểm tra sách có đang được tích chọn hay không
                Row(
                    modifier = Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(8.dp)).padding(8.dp).clickable(enabled = !isOtherBorrowed) {
                        onSelectionChange(if (isChecked) selectedBooks - s else selectedBooks + s) // Tích hoặc Bỏ tích sách
                    },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(checked = isChecked, onCheckedChange = { onSelectionChange(if (it) selectedBooks + s else selectedBooks - s) }, enabled = !isOtherBorrowed, colors = CheckboxDefaults.colors(checkedColor = UthRed))
                    Text(s.title, color = if (isOtherBorrowed) Color.Gray else Color.Black) // Chữ xám nếu sách đã bị mượn bởi người khác
                }
            }
        }
    }
    Spacer(modifier = Modifier.height(16.dp))
    Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        Button(onClick = onSave, modifier = Modifier.width(150.dp).height(50.dp), shape = RoundedCornerShape(12.dp), colors = ButtonDefaults.buttonColors(containerColor = UthBlue)) {
            Text("Thêm", fontWeight = FontWeight.Bold, fontSize = 16.sp) // Nút bấm thực hiện Mượn / Trả sách
        }
    }
}

// Khung UI dùng chung cho Tab 1 & Tab 2 (Thêm Sách mới / Thêm Sinh viên mới)
@Composable
fun TabThemInput(title: String, label: String, btnText: String, onAdd: (String) -> Unit, listContent: @Composable () -> Unit) {
    var text by remember { mutableStateOf("") }
    Text(title, fontWeight = FontWeight.Bold, fontSize = 18.sp, color = UthBlue)
    Spacer(modifier = Modifier.height(16.dp))
    Row(verticalAlignment = Alignment.CenterVertically) {
        OutlinedTextField(value = text, onValueChange = { text = it }, label = { Text(label) }, modifier = Modifier.weight(1f), singleLine = true, shape = RoundedCornerShape(8.dp))
        Spacer(modifier = Modifier.width(8.dp))
        Button(onClick = { if (text.isNotBlank()) { onAdd(text); text = "" } }, shape = RoundedCornerShape(8.dp), colors = ButtonDefaults.buttonColors(containerColor = UthBlue), modifier = Modifier.height(56.dp)) { Text(btnText) } // Bấm nút để Thêm
    }
    Spacer(modifier = Modifier.height(16.dp))
    listContent() // Hiển thị danh sách bên dưới
}
// BÀI TẬP 3: SMARTTASKS (DATA FLOW NAVIGATION)

@Composable
fun SmartTasksHeader(navController: NavController, showBackButton: Boolean = true) {
    Box(modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp)) {
        if (showBackButton) {
            Box(
                modifier = Modifier.size(36.dp).clip(CircleShape).background(SmartBlue).clickable { navController.popBackStack() }.align(Alignment.CenterStart), // Nút back xanh tròn
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Color.White, modifier = Modifier.size(20.dp))
            }
        }
        Column(modifier = Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("UTH", color = UthGreen, fontSize = 32.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.sp) // Chữ UTH Xanh lá
            Text("UNIVERSITY OF TRANSPORT\nHOCHIMINH CITY", color = UthRed, fontSize = 8.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, lineHeight = 10.sp) // Tên trường màu Đỏ
            Spacer(modifier = Modifier.height(6.dp))
            Text("SmartTasks", color = SmartBlue, fontSize = 18.sp, fontWeight = FontWeight.Bold) // Tiêu đề ứng dụng Xanh da trời
        }
    }
}

// Khung nhập dữ liệu dùng chung cho SmartTasks
@Composable
fun SmartTextField(value: String, onValueChange: (String) -> Unit, placeholder: String, icon: androidx.compose.ui.graphics.vector.ImageVector, readOnly: Boolean = false) {
    OutlinedTextField(
        value = value, onValueChange = onValueChange,
        placeholder = { Text(placeholder, color = Color.LightGray, fontSize = 14.sp) }, // Dòng chữ gợi ý nhạt
        leadingIcon = { Icon(icon, "", tint = Color.Gray, modifier = Modifier.size(20.dp)) }, // Biểu tượng icon bên trái
        readOnly = readOnly, // Khóa không cho sửa nếu là màn hình Confirm
        modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp),
        colors = OutlinedTextFieldDefaults.colors(unfocusedBorderColor = Color(0xFFE5E7EB), focusedBorderColor = SmartBlue),
        singleLine = true
    )
}

// Nút bấm xanh da trời dùng chung cho SmartTasks
@Composable
fun SmartButton(text: String, onClick: () -> Unit) {
    Button(
        onClick = onClick, // Sự kiện chuyển trang
        modifier = Modifier.fillMaxWidth().height(46.dp),
        colors = ButtonDefaults.buttonColors(containerColor = SmartBlue),
        shape = RoundedCornerShape(24.dp) // Nút bo tròn góc 24dp
    ) { Text(text, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color.White) }
}

// Màn hình 1: Quên mật khẩu (Nhập Email)
@Composable
fun ForgotPasswordScreen(navController: NavController) {
    var email by remember { mutableStateOf("") } // Biến lưu chuỗi Email người dùng gõ
    Column(modifier = Modifier.fillMaxSize().background(Color.White).padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        SmartTasksHeader(navController, showBackButton = false) // Header không có nút back ở màn 1
        Text("Forget Password?", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.Black)
        Spacer(modifier = Modifier.height(6.dp))
        Text("Enter your Email, we will send you a verification\ncode.", color = Color.Gray, textAlign = TextAlign.Center, fontSize = 12.sp, lineHeight = 16.sp)
        Spacer(modifier = Modifier.height(20.dp))
        SmartTextField(email, { email = it }, "Your Email", Icons.Default.Email) // Ô nhập Email
        Spacer(modifier = Modifier.height(20.dp))
        SmartButton("Next") { navController.navigate("verify/${email.ifBlank { "uth@gmail.com" }}") } // Bấm Next -> Truyền Email sang Màn hình 2
    }
}

// Màn hình 2: Nhập mã OTP
@Composable
fun VerifyCodeScreen(navController: NavController, email: String) {
    var otp by remember { mutableStateOf("") } // Biến lưu mã OTP 5 chữ số
    Column(modifier = Modifier.fillMaxSize().background(Color.White).padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        SmartTasksHeader(navController, showBackButton = true)
        Text("Verify Code", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.Black)
        Spacer(modifier = Modifier.height(6.dp))
        Text("Enter the the code\nwe just sent you on your registered Email", color = Color.Gray, textAlign = TextAlign.Center, fontSize = 12.sp, lineHeight = 16.sp)
        Spacer(modifier = Modifier.height(24.dp))

        // Giao diện 5 ô vuông bo góc chứa chữ số OTP
        Box(contentAlignment = Alignment.Center) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                repeat(5) { i ->
                    val char = if (i < otp.length) otp[i].toString() else ""
                    Box(modifier = Modifier.size(52.dp).background(Color(0xFFF3F4F6), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                        Text(char, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.Black) // Hiển thị từng ký tự số
                    }
                }
            }
            // Khung nhập liệu trong suốt phủ lên trên 5 ô vuông để nhận thao tác gõ phím
            BasicTextField(
                value = otp,
                onValueChange = { if (it.length <= 5 && it.all { c -> c.isDigit() }) otp = it }, // Giới hạn chỉ gõ tối đa 5 chữ số
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.matchParentSize(),
                textStyle = TextStyle(color = Color.Transparent),
                cursorBrush = SolidColor(Color.Transparent)
            )
        }
        Spacer(modifier = Modifier.height(30.dp))
        SmartButton("Next") { navController.navigate("create/$email/${otp.ifBlank { "123456" }}") } // Bấm Next -> Truyền tiếp Email + OTP sang Màn hình 3
    }
}

// Màn hình 3: Tạo mật khẩu mới
@Composable
fun CreatePasswordScreen(navController: NavController, email: String, otp: String) {
    var pass by remember { mutableStateOf("") } // Biến lưu Mật khẩu mới
    var confirmPass by remember { mutableStateOf("") } // Biến lưu Mật khẩu xác nhận
    Column(modifier = Modifier.fillMaxSize().background(Color.White).padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        SmartTasksHeader(navController, showBackButton = true)
        Text("Create new password", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.Black)
        Spacer(modifier = Modifier.height(6.dp))
        Text("Your new password must be different form\npreviously used password", color = Color.Gray, textAlign = TextAlign.Center, fontSize = 12.sp, lineHeight = 16.sp)
        Spacer(modifier = Modifier.height(20.dp))
        SmartTextField(pass, { pass = it }, "Password", Icons.Default.Lock) // Ô nhập Pass
        Spacer(modifier = Modifier.height(10.dp))
        SmartTextField(confirmPass, { confirmPass = it }, "Confirm Password", Icons.Default.Lock) // Ô nhập Confirm Pass
        Spacer(modifier = Modifier.height(20.dp))
        SmartButton("Next") { navController.navigate("confirm/$email/$otp/${pass.ifBlank { "**********" }}") } // Bấm Next -> Truyền Email + OTP + Pass sang Màn 4
    }
}

// Màn hình 4: Xác nhận (Hiển thị đầy đủ thông tin đã truyền qua 3 màn trước)
@Composable
fun ConfirmScreen(navController: NavController, email: String, otp: String, pass: String) {
    Column(modifier = Modifier.fillMaxSize().background(Color.White).padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        SmartTasksHeader(navController, showBackButton = true)
        Text("Confirm", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.Black)
        Spacer(modifier = Modifier.height(6.dp))
        Text("We are here to help you!", color = Color.Gray, textAlign = TextAlign.Center, fontSize = 12.sp)
        Spacer(modifier = Modifier.height(20.dp))
        SmartTextField(email.ifBlank { "uth@gmail.com" }, {}, "", Icons.Default.Person, readOnly = true) // Hiển thị Email đã nhận
        Spacer(modifier = Modifier.height(10.dp))
        SmartTextField(otp.ifBlank { "123456" }, {}, "", Icons.Default.Email, readOnly = true) // Hiển thị OTP đã nhận
        Spacer(modifier = Modifier.height(10.dp))
        SmartTextField("**********", {}, "", Icons.Default.Lock, readOnly = true) // Hiển thị chuỗi Password dạng dấu sao
        Spacer(modifier = Modifier.height(24.dp))
        SmartButton("Summit") { navController.navigate("menu") { popUpTo(0) } } // Bấm Summit để hoàn thành và quay lại Menu chính
    }
}