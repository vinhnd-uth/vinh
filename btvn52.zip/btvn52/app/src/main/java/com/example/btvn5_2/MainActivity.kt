package com.example.btvn5_2

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.FormatListBulleted
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.btvn5_2.ui.theme.Btvn52Theme

enum class Category(val displayName: String) { HOC_TAP("Học tập"), CUOC_SONG("Cuộc sống") }
data class Task(val id: String, val title: String, val category: Category, val time: String, var isCompleted: Boolean = false)

object FirebaseService {
    var currentUser = "Minh Anh"
    fun getTasks() = mutableStateListOf(
        Task("1", "Tập thể dục 30 phút", Category.CUOC_SONG, "06:30", true),
        Task("2", "Nộp bài tập Lập trình di động", Category.HOC_TAP, "09:00", true),
        Task("3", "Ôn chương 3 – Cấu trúc dữ liệu", Category.HOC_TAP, "14:00", false),
        Task("4", "Đi chợ mua đồ cho tuần", Category.CUOC_SONG, "17:30", false)
    )
    val notifications = mutableStateListOf(
        "Nhắc nhở: Hạn nộp bài Lập trình di động lúc 09:00",
        "Đã hoàn thành 50% tiến độ công việc hôm nay!",
        "Hệ thống UTH Firebase Auth đã sẵn sàng"
    )
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { Btvn52Theme { HomeScreen() } }
    }
}

@Preview
@Composable
fun HomeScreen() {
    val tasks = remember { FirebaseService.getTasks() }
    val notifications = remember { FirebaseService.notifications }
    var user by remember { mutableStateOf(FirebaseService.currentUser) }
    var selCat by remember { mutableStateOf<Category?>(null) }
    var selTab by remember { mutableIntStateOf(0) }
    var showAdd by remember { mutableStateOf(false) }

    val total = tasks.size
    val done = tasks.count { it.isCompleted }
    val htLeft = tasks.count { it.category == Category.HOC_TAP && !it.isCompleted }
    val csLeft = tasks.count { it.category == Category.CUOC_SONG && !it.isCompleted }
    val displayed = if (selCat != null) tasks.filter { it.category == selCat } else tasks

    Scaffold(
        containerColor = Color(0xFFF8FAFC),
        bottomBar = {
            Surface(shadowElevation = 8.dp, color = Color.White) {
                Row(Modifier.fillMaxWidth().navigationBarsPadding().padding(vertical = 6.dp), Arrangement.SpaceAround, Alignment.CenterVertically) {
                    NavBtn(Icons.Outlined.Home, "Trang chủ", selTab == 0) { selTab = 0 }
                    NavBtn(Icons.AutoMirrored.Outlined.FormatListBulleted, "Danh sách", selTab == 1) { selTab = 1 }
                    Box(Modifier.size(46.dp).clip(CircleShape).background(Color(0xFF2563EB)).clickable { showAdd = true }, Alignment.Center) { Icon(Icons.Default.Add, "Thêm", tint = Color.White) }
                    NavBtn(Icons.Outlined.Notifications, "Thông báo", selTab == 2) { selTab = 2 }
                    NavBtn(Icons.Outlined.Tune, "Cài đặt", selTab == 3) { selTab = 3 }
                }
            }
        }
    ) { p ->
        Column(Modifier.fillMaxSize().padding(p).statusBarsPadding().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(42.dp).clip(CircleShape).background(Color(0xFFDBEAFE)), Alignment.Center) { Text(if (user.contains(" ")) user.split(" ").last().take(2).uppercase() else "MA", color = Color(0xFF1D4ED8), fontWeight = FontWeight.Bold) }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text("Thứ Ba, 20 tháng 10", color = Color(0xFF64748B), fontSize = 12.sp)
                    Text("Chào $user!", color = Color(0xFF0F172A), fontSize = 18.sp, fontWeight = FontWeight.Bold)
                }
                Surface(shape = RoundedCornerShape(12.dp), color = Color.White, shadowElevation = 1.dp, onClick = { selTab = 2 }) { Icon(Icons.Outlined.Notifications, null, modifier = Modifier.padding(8.dp).size(20.dp)) }
            }
            Spacer(Modifier.height(12.dp))

            when (selTab) {
                0 -> {
                    Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF2563EB))) {
                        Row(Modifier.padding(16.dp).fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("Tiến độ hôm nay", color = Color.White.copy(0.8f), fontSize = 12.sp)
                                Text("$done/$total việc", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                                Text("Đã hơn nửa chặng, cố lên!", color = Color.White.copy(0.8f), fontSize = 11.sp)
                            }
                            Box(Modifier.size(56.dp).clip(CircleShape).background(Color.White.copy(0.2f)), Alignment.Center) {
                                val pct = if (total > 0) done.toFloat() / total else 0f
                                Canvas(Modifier.size(46.dp)) {
                                    drawCircle(Color.White.copy(0.3f), style = Stroke(4.dp.toPx()))
                                    drawArc(Color.White, -90f, 360f * pct, false, style = Stroke(4.dp.toPx(), cap = StrokeCap.Round))
                                }
                                Text("${(pct * 100).toInt()}%", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        CatCard(Modifier.weight(1f), "Học tập", "$htLeft việc còn lại", Icons.Outlined.School, Color(0xFFEFF6FF), Color(0xFF2563EB), selCat == Category.HOC_TAP) { selCat = if (selCat == Category.HOC_TAP) null else Category.HOC_TAP }
                        CatCard(Modifier.weight(1f), "Cuộc sống", "$csLeft việc còn lại", Icons.Outlined.Home, Color(0xFFFFF7ED), Color(0xFFEA580C), selCat == Category.CUOC_SONG) { selCat = if (selCat == Category.CUOC_SONG) null else Category.CUOC_SONG }
                    }
                    Spacer(Modifier.height(14.dp))
                    Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                        Text("Việc hôm nay", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        TextButton({ selCat = null }) { Text("Xem tất cả", color = Color(0xFF2563EB), fontSize = 13.sp) }
                    }
                    TaskList(displayed, tasks)
                }
                1 -> {
                    Text("Tất cả công việc (${tasks.size})", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(selCat == null, { selCat = null }, { Text("Tất cả") })
                        FilterChip(selCat == Category.HOC_TAP, { selCat = Category.HOC_TAP }, { Text("Học tập") })
                        FilterChip(selCat == Category.CUOC_SONG, { selCat = Category.CUOC_SONG }, { Text("Cuộc sống") })
                    }
                    Spacer(Modifier.height(10.dp))
                    TaskList(displayed, tasks, canDelete = true)
                }
                2 -> {
                    Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                        Text("Thông báo hệ thống", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        if (notifications.isNotEmpty()) TextButton({ notifications.clear() }) { Text("Xóa tất cả") }
                    }
                    Spacer(Modifier.height(8.dp))
                    if (notifications.isEmpty()) Text("Không có thông báo mới", color = Color(0xFF64748B))
                    notifications.forEach { note ->
                        Card(Modifier.fillMaxWidth().padding(vertical = 4.dp), shape = RoundedCornerShape(12.dp), colors = CardDefaults.cardColors(Color.White)) {
                            Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Outlined.Notifications, null, tint = Color(0xFF2563EB))
                                Spacer(Modifier.width(10.dp))
                                Text(note, fontSize = 13.sp, color = Color(0xFF0F172A))
                            }
                        }
                    }
                }
                3 -> {
                    Text("Cài đặt tài khoản UTH Auth", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(12.dp))
                    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp), colors = CardDefaults.cardColors(Color.White)) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("Người dùng: $user", fontWeight = FontWeight.Bold)
                            Text("Email: minhanh.uth@gmail.com", color = Color(0xFF64748B), fontSize = 13.sp)
                            Text("Firebase Sync Status: Connected", color = Color(0xFF16A34A), fontSize = 13.sp)
                            Button({
                                user = if (user == "Minh Anh") "Nguyễn Văn A" else "Minh Anh"
                                FirebaseService.currentUser = user
                            }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB))) {
                                Text("Đổi tài khoản Firebase Auth")
                            }
                        }
                    }
                }
            }
        }
        if (showAdd) {
            var title by remember { mutableStateOf("") }
            var cat by remember { mutableStateOf(Category.HOC_TAP) }
            AlertDialog(
                onDismissRequest = { showAdd = false },
                title = { Text("Thêm công việc Firebase") },
                text = {
                    Column {
                        OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Tên công việc") })
                        Row(Modifier.padding(top = 8.dp), Arrangement.spacedBy(8.dp)) {
                            FilterChip(cat == Category.HOC_TAP, { cat = Category.HOC_TAP }, { Text("Học tập") })
                            FilterChip(cat == Category.CUOC_SONG, { cat = Category.CUOC_SONG }, { Text("Cuộc sống") })
                        }
                    }
                },
                confirmButton = { Button({ if (title.isNotBlank()) { tasks.add(0, Task(System.currentTimeMillis().toString(), title, cat, "12:00")); showAdd = false } }) { Text("Thêm") } },
                dismissButton = { TextButton({ showAdd = false }) { Text("Hủy") } }
            )
        }
    }
}

@Composable
private fun TaskList(displayed: List<Task>, tasks: SnapshotStateList<Task>, canDelete: Boolean = false) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        displayed.forEach { item ->
            Card(Modifier.fillMaxWidth().clickable {
                val idx = tasks.indexOf(item)
                if (idx != -1) tasks[idx] = item.copy(isCompleted = !item.isCompleted)
            }, shape = RoundedCornerShape(14.dp), colors = CardDefaults.cardColors(Color.White)) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(22.dp).clip(CircleShape).background(if (item.isCompleted) Color(0xFF2563EB) else Color(0xFFE2E8F0)), Alignment.Center) {
                        if (item.isCompleted) Icon(Icons.Default.Check, null, tint = Color.White, modifier = Modifier.size(14.dp))
                    }
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(item.title, fontWeight = FontWeight.SemiBold, color = if (item.isCompleted) Color(0xFF94A3B8) else Color(0xFF0F172A), textDecoration = if (item.isCompleted) TextDecoration.LineThrough else null, fontSize = 14.sp)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            val ht = item.category == Category.HOC_TAP
                            Surface(shape = RoundedCornerShape(4.dp), color = if (ht) Color(0xFFEFF6FF) else Color(0xFFFFF7ED)) {
                                Text(item.category.displayName, color = if (ht) Color(0xFF2563EB) else Color(0xFFEA580C), fontSize = 10.sp, modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp))
                            }
                            Spacer(Modifier.width(6.dp))
                            Text(item.time, color = Color(0xFF64748B), fontSize = 11.sp)
                        }
                    }
                    if (canDelete) {
                        IconButton({ tasks.remove(item) }, Modifier.size(24.dp)) { Icon(Icons.Default.Delete, "Xóa", tint = Color(0xFFEF4444), modifier = Modifier.size(18.dp)) }
                    } else {
                        Icon(Icons.Default.ChevronRight, null, tint = Color(0xFFCBD5E1), modifier = Modifier.size(18.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun CatCard(modifier: Modifier, title: String, sub: String, icon: ImageVector, bg: Color, icColor: Color, sel: Boolean, onClick: () -> Unit) {
    Card(modifier.clickable(onClick = onClick), shape = RoundedCornerShape(14.dp), colors = CardDefaults.cardColors(if (sel) bg.copy(0.7f) else bg)) {
        Column(Modifier.padding(14.dp)) {
            Box(Modifier.size(32.dp).clip(CircleShape).background(Color.White), Alignment.Center) { Icon(icon, null, tint = icColor, modifier = Modifier.size(18.dp)) }
            Spacer(Modifier.height(8.dp))
            Text(title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text(sub, fontSize = 11.sp, color = Color(0xFF64748B))
        }
    }
}

@Composable
private fun NavBtn(icon: ImageVector, label: String, sel: Boolean, onClick: () -> Unit) {
    val c = if (sel) Color(0xFF2563EB) else Color(0xFF64748B)
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable(onClick = onClick)) {
        Icon(icon, label, tint = c, modifier = Modifier.size(20.dp))
        Text(label, color = c, fontSize = 10.sp)
    }
}
